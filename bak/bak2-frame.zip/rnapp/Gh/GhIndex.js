import React from 'react';
import { render } from 'react-dom';

class GhIndex extends React.Component {
    render() {
        return (
            <div>干货集中营首页首页首页</div>
        );
    }
}

render(<GhIndex />, document.getElementById('content'));
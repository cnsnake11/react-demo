import React from 'react';
import { render } from 'react-dom';

import css from './comm.css';

console.log('in comm.js');
alert('in comm.js');


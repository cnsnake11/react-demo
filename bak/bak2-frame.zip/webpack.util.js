
"use strict";

let Logger = require("./webpack.util.log.js");
let fs = require('fs-extra');

let log = new Logger();

class Util {

    constructor(options) {
        this.rootPath = options.rootPath;
    }

    getEntrys() {

    }

    getOutput() {

    }

}


module.exports = Util;

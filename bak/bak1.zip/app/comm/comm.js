import React from 'react';
import { render } from 'react-dom';

console.log('in comm.js');


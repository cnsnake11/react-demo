import React from 'react';
import { render } from 'react-dom';

//import css from './index.css';

class HelloWorld extends React.Component {
    render() {
        return (
            <div>Hello World 1111111111111</div>
    );
    }
}

render(<HelloWorld />, document.getElementById('content'));